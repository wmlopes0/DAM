
package ejercicio3;

/**
 *
 * @author wmartinl01
 */
public class Constantes {
    
    final static int ANCHO_IMAGEN = 50;
    final static int ALTO_IMAGEN = 50;
}
