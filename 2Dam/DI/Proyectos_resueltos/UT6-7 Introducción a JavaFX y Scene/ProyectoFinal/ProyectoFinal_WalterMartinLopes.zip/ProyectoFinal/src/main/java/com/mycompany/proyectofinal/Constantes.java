
package com.mycompany.proyectofinal;

/**
 *
 * @author Walter
 */
public class Constantes {
    
    public final static String BD = "fitness_valle";
    public final static String PUERTO = "3306";
    public final static String USUARIO = "root";
    
    public final static String SQLEXCEPTION = "ERROR: SQLException.";
    public final static String INTERRUPTED_EXCEPTION = "ERROR: InterruptedException.";
    public final static String CLASS_NOT_FOUND_EXCEPTION = "ERROR: ClassNotFoundException.";
    public final static String CONEXION_FALLIDA = "\n ERROR: CONEXIÓN FALLIDA.";
}
