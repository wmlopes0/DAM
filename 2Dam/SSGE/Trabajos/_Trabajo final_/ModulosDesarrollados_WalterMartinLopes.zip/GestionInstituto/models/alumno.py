from odoo import models, fields, api


class Alumno(models.Model):
    _name = 'alumno.formativo'  # Define el nombre técnico del modelo en Odoo
    _description = 'Alumno'  # Descripción

    # Campos del modelo
    nombre = fields.Char(string="Nombre", required=True)  # Nombre del alumno
    dni = fields.Char(string="DNI", required=True)  # DNI del alumno
    email = fields.Char(string="Email", required=True)  # Email del alumno

    # Relaciones
    # Campo many2many que relaciona el alumno con los módulos.
    # Se utiliza la misma tabla de relación 'modulo_alumno_rel' especificada en el modelo Modulo para la relación inversa.
    modulo_ids = fields.Many2many('modulo.formativo', 'modulo_alumno_rel',
                                  'alumno_id', 'modulo_id', string="Módulos Matriculados")

    # Get name para mostrar el nombre
    @api.depends('nombre')
    def name_get(self):
        result = []
        for record in self:
            name = record.nombre
            result.append((record.id, name))
        return result
