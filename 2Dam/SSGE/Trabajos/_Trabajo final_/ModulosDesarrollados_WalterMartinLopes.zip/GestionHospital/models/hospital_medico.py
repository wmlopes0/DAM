# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import models, fields, api
from odoo.exceptions import ValidationError

#Definimos modelo HospitalMedico
class HospitalMedico(models.Model):
    _name = 'hospital.medico'  # Define el nombre técnico del modelo
    _description = 'Médico'    # Descripción
    _rec_name = 'nombre'       # Especifica el campo a usar como representación de nombre del registro

    nombre = fields.Char(string='Nombre y Apellidos', required=True, index=True)  # Campo para el nombre, obligatorio e indexado para optimizar búsquedas
    numero_colegiado = fields.Char(string='Número de Colegiado', required=True)  # Campo para el número de colegiado

    pacientes_atendidos = fields.Many2many('hospital.paciente', string='Pacientes Atendidos', relation='hospital_medico_paciente_rel', column1='medico_id', column2='paciente_id', help='Pacientes atendidos por este médico')  # Campo para relacionar médicos con pacientes

    _sql_constraints = [
        ('numero_colegiado_uniq', 'UNIQUE(numero_colegiado)', 'El número de colegiado debe ser único.'),  # Restricción de SQL para garantizar números de colegiado únicos
    ]