module com.clase.ejercicio2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.clase.ejercicio2 to javafx.fxml;
    exports com.clase.ejercicio2;
}
