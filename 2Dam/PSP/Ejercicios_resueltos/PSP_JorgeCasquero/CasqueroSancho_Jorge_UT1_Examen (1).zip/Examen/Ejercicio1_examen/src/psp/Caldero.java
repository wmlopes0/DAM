package psp;

public class Caldero {
	private Piruja piruja;
	private Bruja bruja;
	private int nRaciones;

	public Caldero() {

		this.piruja = piruja;
		this.bruja = bruja;
		this.nRaciones = 3;
	}

	/**
	 * @return the piruja
	 */
	public Piruja getPiruja() {
		return piruja;
	}

	/**
	 * @param piruja the piruja to set
	 */
	public void setPiruja(Piruja piruja) {
		this.piruja = piruja;
	}

	/**
	 * @return the bruja
	 */
	public Bruja getBruja() {
		return bruja;
	}

	public synchronized void beber(String nombreBruja) {

		while (nRaciones == 0) {// mientras las raciones son 0 = caldero vacio

			try {
				System.out.println("\t" + nombreBruja + " espera , se está rellenando la pócima");
				wait();

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		this.nRaciones--;
		System.out.println(
				"----" + nombreBruja + " está tomando su racion de pócima mágica Raciones restantes: " + nRaciones);
		// si se acaba el caldero, la misma bruja que lo termina 
		if (nRaciones == 0) {
			System.out.println("000- La marmita está vacia, " + nombreBruja + " despierta a Piruja");
		}
		notify();

	}

//metodo por el cual se rellena  el caldero
	synchronized public void Rellenar() {
		while (nRaciones > 0) {// si en el caldero hay alguna racion, Piruja no hace nada no hace nada
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (nRaciones == 0) {

			nRaciones = 3;// el caldero ahora esta lleno
			nRaciones--;
			System.out.println("Piruja ya ha rellenado el caldero, toma una ración. Raciones restantes: " + nRaciones);
			notifyAll();
		}

	}

}
