package psp;

public class Main {

	public static void main(String[] args) {
		Caldero caldero = new Caldero();
		Piruja piruja = new Piruja(caldero);
		Bruja[] bruja = new Bruja[9];
		String[] nombres = { "bruja de blair", "Anastasia", "Griselda", "Morgana", "Maléfica", "Calypso", "Myrtle",
				"Sabrina", "Nancy" };
		piruja.start();
		for (int i = 0; i < nombres.length; i++) {
			
			
			bruja[i] = new Bruja(nombres[i], caldero);
		
			bruja[i].start();

		}
		

	}

}
