package ejercicio2;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author wmartinl01
 */
public class MouseListenerPropio implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent e) {
        JButton boton = (JButton) e.getSource();
        JOptionPane.showMessageDialog(boton, "No deberías de haber pulsado el botón", "Mensaje", JOptionPane.WARNING_MESSAGE);
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        JButton boton = (JButton) e.getSource();
        boton.setText("No pulses");
    }

    @Override
    public void mouseExited(MouseEvent e) {
        JButton boton = (JButton) e.getSource();
        boton.setBackground(Color.yellow);
        boton.setText("Gracias por no pulsar");
    }

}
