package com.clase.ejercicio1;

/**
 *
 * @author wmartinl01
 */
public class Pizza {

    //Atributos
    private int idPizza;
    private String nombre;
    private String foto;
    private String ingredientes;
    private float precio;

    //Constructores
    public Pizza(int idPizza, String nombre, String foto, String ingredientes, float precio) {
        this.idPizza = idPizza;
        this.nombre = nombre;
        this.foto = foto;
        this.ingredientes = ingredientes;
        this.precio = precio;
    }

    public Pizza(String nombre, String foto, String ingredientes, float precio) {
        this.nombre = nombre;
        this.foto = foto;
        this.ingredientes = ingredientes;
        this.precio = precio;
    }

    //Getter y Setter
    public int getIdPizza() {
        return idPizza;
    }

    public void setIdPizza(int idPizza) {
        this.idPizza = idPizza;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

}
