# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import models, fields, api
from odoo.exceptions import ValidationError

#Definimos modelo HospitalDiagnostico
class HospitalDiagnostico(models.Model):
    _name = 'hospital.diagnostico'  # Define el nombre técnico del modelo
    _description = 'Diagnóstico'    # Descripción

    # Campo para relacionar con el paciente
    paciente_id = fields.Many2one('hospital.paciente', string='Paciente', required=True, index=True)
    
    # Campo para relacionar con el médico
    medico_id = fields.Many2one('hospital.medico', string='Médico', required=True, index=True)
    
    # Campo para el diagnóstico, obligatorio
    diagnostico = fields.Text(string='Diagnóstico', required=True)  
    
     # Campo de fecha
    fecha_diagnostico = fields.Date(string='Fecha del Diagnóstico', required=True, default=fields.Date.today())

    _rec_name = 'nombre_paciente_medico'  # Campo para representar el diagnóstico

    # Función calculada para combinar el nombre del paciente y médico
    @api.depends('paciente_id', 'medico_id')
    def _compute_nombre_paciente_medico(self):
        for record in self:
            record.nombre_paciente_medico = f'{record.paciente_id.nombre} - {record.medico_id.nombre}'

    nombre_paciente_medico = fields.Char(string='Paciente - Médico', compute='_compute_nombre_paciente_medico', store=True)

    # Restricción para asegurar que un médico no puede diagnosticarse a sí mismo
    _sql_constraints = [
        ('medico_no_autodiagnostico', 'CHECK(medico_id != paciente_id)', 'Un médico no puede diagnosticarse a sí mismo.'),
    ]