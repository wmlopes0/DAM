package ejercicio1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author wmartinl01
 */
public class LogicaNegocio {

    //Lista
    private List<Pelicula> lPeliculas = new ArrayList<>();

    //Constructor
    public LogicaNegocio() {
        lPeliculas.add(new Pelicula(1, "Indiana Jones", "98 minutos", "Ridley Scott"));
        lPeliculas.add(new Pelicula(2, "Pelicula 2", "58 minutos", "Director 2"));
        lPeliculas.add(new Pelicula(3, "Pelicula 3", "75 minutos", "Director 3"));
        lPeliculas.add(new Pelicula(4, "Pelicula 4", "23 minutos", "Director 4"));
        lPeliculas.add(new Pelicula(5, "Pelicula 5", "108 minutos", "Director 5"));
    }

    //Getter
    public List<Pelicula> getlPeliculas() {
        return lPeliculas;
    }

}
