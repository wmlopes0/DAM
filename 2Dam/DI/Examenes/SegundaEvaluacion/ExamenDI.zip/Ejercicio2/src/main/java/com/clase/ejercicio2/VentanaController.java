/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.clase.ejercicio2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author wmartinl01
 */
public class VentanaController implements Initializable {

    @FXML
    private TextField num1;
    @FXML
    private TextField num3;
    @FXML
    private TextField num2;
    @FXML
    private TextField num4;
    @FXML
    private RadioButton sumarTodos;
    @FXML
    private ToggleGroup grupo;
    @FXML
    private RadioButton multiplicarTodos;
    @FXML
    private Button botonEjecutar;
    @FXML
    private Label resultado;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        sumarTodos.setSelected(true);
    }

    @FXML
    private void ejecutar(ActionEvent event) {
        //Recupero valores y compruebo que están todos rellenos
        int num1 = Integer.parseInt(this.num1.getText());
        int num2 = Integer.parseInt(this.num1.getText());
        int num3 = Integer.parseInt(this.num1.getText());
        int num4 = Integer.parseInt(this.num1.getText());
        int result = 0;
        if (sumarTodos.isSelected()) {
            result = num1 + num2 + num3 + num4;
            resultado.setText(String.valueOf(result));
        } else {
            if (multiplicarTodos.isSelected()) {
                result = num1 * num2 * num3 * num4;
                resultado.setText(String.valueOf(result));
            }
        }
    }

}
