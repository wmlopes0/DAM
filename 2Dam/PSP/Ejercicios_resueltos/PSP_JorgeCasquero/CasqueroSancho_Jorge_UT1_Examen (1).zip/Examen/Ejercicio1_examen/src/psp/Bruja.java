package psp;

public class Bruja extends Thread {
	private String nombre;
	private Caldero caldero;

	public Bruja(String nombre, Caldero caldero) {

		this.nombre = nombre;
		this.caldero = caldero;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Caldero getCaldero() {
		return caldero;
	}

	public void setCaldero(Caldero caldero) {
		this.caldero = caldero;
	}

	@Override
	public void run() {
		caldero.beber(this.nombre);
	}
}
