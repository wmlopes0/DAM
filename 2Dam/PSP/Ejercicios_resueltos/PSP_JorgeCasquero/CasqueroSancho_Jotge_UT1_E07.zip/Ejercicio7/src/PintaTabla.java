import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class PintaTabla extends Thread {
	private int numero;

	public PintaTabla(int num) {

		this.numero = num;

	}

	public void escribir() {

		File fichero = null;
		FileWriter fw = null;

		try {
			fichero = new File("TABLAS\\" + this.numero + ".txt");
			fw = new FileWriter(fichero);
			for (int i = 0; i < 11; i++) {
				fw.write(numero + "x" + i + " = " + (numero * i) + " \n");
			}

		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e2) {
					System.out.println(e2.getMessage());
				}
			}
		}

	}
}
