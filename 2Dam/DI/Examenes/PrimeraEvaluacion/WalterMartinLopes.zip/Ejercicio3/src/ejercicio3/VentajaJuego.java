package ejercicio3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author wmartinl01
 */
public class VentajaJuego extends javax.swing.JFrame {

    //Variables globales
    private ImageIcon barco;
    private boolean[][] casillasCPU = new boolean[5][5];
    private boolean[][] casillasUser = new boolean[5][5];
    private int casillasMarcadasUser = 0;

    //Constructor
    public VentajaJuego() {
        initComponents();
        inicializarCasillasCPU();
        recuperarImagenBarco();
        generarTableros();
        JOptionPane.showMessageDialog(this, "Marca 7 casillas de tu tablero para comenzar a jugar", "Inicio", JOptionPane.INFORMATION_MESSAGE);
    }

    //Generar tableros
    public void generarTableros() {
        jPanelUsuario.setLayout(new GridLayout(5, 5));
        jPanelCpu.setLayout(new GridLayout(5, 5));
        //Introduzco botones en panel CPU
        for (int i = 0; i < 25; i++) {
            JButton casilla = new JButton();
            casilla.setPreferredSize(new Dimension(Constantes.ANCHO_IMAGEN, Constantes.ALTO_IMAGEN));
            casilla.setBackground(Color.WHITE);
            jPanelCpu.add(casilla);
        }
        //Introduzco botones en panel User
        for (int i = 0; i < 25; i++) {
            JButton casilla = new JButton();
            casilla.setPreferredSize(new Dimension(Constantes.ANCHO_IMAGEN, Constantes.ALTO_IMAGEN));
            casilla.setBackground(Color.WHITE);
            addActionListenerUser(casilla);
            jPanelUsuario.add(casilla);
        }
    }

    //  Refrescar paneles
    public void refrescarPanelUser() {
        //Refrescar panel USER
        jPanelUsuario.removeAll();
        jPanelUsuario.revalidate();
        jPanelUsuario.repaint();

        for (int i = 0; i < casillasUser.length; i++) {
            for (int j = 0; j < casillasUser[i].length; j++) {
                JButton casilla = new JButton();
                addActionListenerUser(casilla);
                if (casillasUser[i][j]) {
                    casilla.setIcon(barco);
                } else {
                    casilla.setPreferredSize(new Dimension(Constantes.ANCHO_IMAGEN, Constantes.ALTO_IMAGEN));
                    casilla.setBackground(Color.WHITE);
                }
                jPanelUsuario.add(casilla);
            }
        }
    }

    //Action listener boton usuario
    public void addActionListenerUser(JButton boton) {
        boolean marcada = false;
        boton.addActionListener((ActionEvent e) -> {
            if (casillasMarcadasUser != 6) {
                boton.setIcon(barco);
                casillasMarcadasUser++;
            } else {
                boton.setIcon(barco);
                JOptionPane.showMessageDialog(this, "EMPIEZA EL JUEGO,PULSA ALGUNA CASILLA DE CPU", "A jugar!", JOptionPane.INFORMATION_MESSAGE);
                aniadirActionListenerCPU();
            }
        });
    }

    //Añado el action listener al CPU
    public void aniadirActionListenerCPU() {
        jPanelCpu.removeAll();
        jPanelCpu.revalidate();
        jPanelCpu.repaint();
        for (int i = 0; i < casillasCPU.length; i++) {
            for (int j = 0; j < casillasCPU[i].length; j++) {
                JButton casilla = new JButton();
                casilla.setPreferredSize(new Dimension(Constantes.ANCHO_IMAGEN, Constantes.ALTO_IMAGEN));
                actionListenerCpu(casilla, casillasCPU[i][j]);
                jPanelCpu.add(casilla);
            }
        }
    }

    public void actionListenerCpu(JButton boton, boolean barco) {
        boton.addActionListener((ActionEvent e) -> {
            if (barco) {
                boton.setBackground(Color.red);

            } else {
                boton.setBackground(Color.blue);
            }
        });
        turnoCPU();
    }

    //Turno CPU
    public void turnoCPU() {
        int fila = generarAleatorio(0, 4);
        int columna = generarAleatorio(0, 4);
        //VOY POR AQUI
        
    }

    //Inicializar casilasBoolean
    public void inicializarCasillasCPU() {
        int fila = 0;
        int columna = 0;
        int contador = 0;

        for (int i = 0; i < casillasCPU.length; i++) {
            for (int j = 0; j < casillasCPU[i].length; j++) {
                fila = generarAleatorio(0, 4);
                columna = generarAleatorio(0, 4);
                if (casillasCPU[fila][columna] != true && contador < 7) {
                    casillasCPU[fila][columna] = true;
                    System.out.println("CPU elige, fila " + fila + " columna " + columna);
                    contador++;
                }
            }
        }
    }

    //Generar aleatorio
    public int generarAleatorio(int inicio, int fin) {
        return new Random().nextInt(inicio, (fin + 1));
    }

    //Recuperar imagen barco
    public void recuperarImagenBarco() {
        ImageIcon imageIcon = new ImageIcon(getClass().getResource("/IMG/barco.png"));
        Image image = imageIcon.getImage();
        Image newimg = image.getScaledInstance(Constantes.ANCHO_IMAGEN, Constantes.ALTO_IMAGEN, java.awt.Image.SCALE_SMOOTH);
        barco = new ImageIcon(newimg);
    }

    //Código generado
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelUsuario = new javax.swing.JPanel();
        jPanelCpu = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        javax.swing.GroupLayout jPanelUsuarioLayout = new javax.swing.GroupLayout(jPanelUsuario);
        jPanelUsuario.setLayout(jPanelUsuarioLayout);
        jPanelUsuarioLayout.setHorizontalGroup(
            jPanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanelUsuarioLayout.setVerticalGroup(
            jPanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanelCpuLayout = new javax.swing.GroupLayout(jPanelCpu);
        jPanelCpu.setLayout(jPanelCpuLayout);
        jPanelCpuLayout.setHorizontalGroup(
            jPanelCpuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanelCpuLayout.setVerticalGroup(
            jPanelCpuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel1.setText("USUARIO");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel2.setText("CPU");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel3.setText("JUEGO HUNDIR LA FLOTA");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(188, 188, 188)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(189, 189, 189))
            .addGroup(layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jPanelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 119, Short.MAX_VALUE)
                .addComponent(jPanelCpu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel3)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanelCpu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(126, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Main
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentajaJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentajaJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentajaJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentajaJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentajaJuego().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanelCpu;
    private javax.swing.JPanel jPanelUsuario;
    // End of variables declaration//GEN-END:variables
}
