package com.clase.ejercicio1;

import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author wmartinl01
 */
public class FormularioAniadirPizzaController implements Initializable {

    @FXML
    private Button botonAniadir;
    @FXML
    private TextField inputDireccion;
    @FXML
    private ComboBox<String> comboPizza;

    private ObservableList<Pizza> lPizzas;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void aniadir(ActionEvent event) {
        //Recupero valores input
        String direccion = inputDireccion.getText();
        int idPizza = recuperarIdPizza();
        //Compruebo que están todos los campos rellenados
        if (direccion != "") {
            //Creo pedido
            Pedido pedido = new Pedido(idPizza, direccion);
            //Añado pedido a la bd
            Utileria.aniadirPedido(pedido);
            //Reseteo campos
            inputDireccion.setText("");
            //Alert CHECK
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setTitle("CHECK");
            alert.setContentText("¡Pedido añadido correctamente!");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("¡Todos los campos deben estar rellenos!");
            alert.showAndWait();
        }
    }

    public void iniciarComboBox() {
        for (Pizza pizza : lPizzas) {
            comboPizza.getItems().add(pizza.getNombre());
        }
        comboPizza.setValue("Verata");
    }

    void iniciarAtributos(ObservableList<Pizza> lPizzas) {
        this.lPizzas = lPizzas;
        iniciarComboBox();
    }

    public int recuperarIdPizza() {
        int idPizza = 1;
        //Recupero el valor del comboBox
        String nombrePizza = comboPizza.getValue();
        for (Pizza pizza : lPizzas) {
            if (nombrePizza.equalsIgnoreCase(pizza.getNombre())) {
                idPizza = pizza.getIdPizza();
            }
        }
        return idPizza;
    }

}
