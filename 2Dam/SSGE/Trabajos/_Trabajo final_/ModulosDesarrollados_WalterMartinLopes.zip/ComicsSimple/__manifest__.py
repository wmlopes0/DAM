# -*- coding: utf-8 -*-
{
    'name': "Biblioteca Comics Simple",  # Titulo del módulo
    'summary': "Gestionar comics :) (Version simple)",  # Resumen de la funcionaliadad
    'description': """
Gestor de bibliotecas (Version Simple)
==============
    """,  

    #Indicamos que es una aplicación
    'application': True,
    'author': "Walter Martin Lopes",
    'website': "http://apuntesfpinformatica.es",
    'category': 'Tools',
    'version': '0.1',
    'depends': ['base'],

    'data': [
        #Estos dos primeros ficheros:
        #1) El primero indica grupo de seguridad basado en rol
        #2) El segundo indica la politica de acceso del modelo
        'security/groups.xml',
        'security/ir.model.access.csv',
        #Cargamos las vistas
        'views/biblioteca_comic.xml',
        'views/biblioteca_socio.xml',
        'views/biblioteca_comicEjemplar.xml'
    ],
}
