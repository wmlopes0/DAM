package ejercicio1;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author wmartinl01
 */
public class PeliculaTableModel extends AbstractTableModel {

    //Atributos
    private List<Pelicula> lPeliculas = new ArrayList<>();
    private String[] nombreColumnas = {"ID", "Titulo", "Duracion", "Director"};

    //Constructor
    public PeliculaTableModel(List<Pelicula> lPeliculas) {
        this.lPeliculas = lPeliculas;
    }

    //Método para añadir una película
    public void addPelicula(Pelicula pelicula) {
        lPeliculas.add(pelicula);
        fireTableDataChanged();//Actualizo la tabla
    }

    @Override
    public int getRowCount() {
        return lPeliculas.size();
    }

    @Override
    public int getColumnCount() {
        return nombreColumnas.length;
    }

    @Override
    public String getColumnName(int column) {
        return nombreColumnas[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return lPeliculas.get(rowIndex).getIdPelicula();
            case 1:
                return lPeliculas.get(rowIndex).getTitulo();
            case 2:
                return lPeliculas.get(rowIndex).getDuracion();
            case 3:
                return lPeliculas.get(rowIndex).getDirector();
            default:
                return null;
        }
    }

}
