# -*- coding: utf-8 -*-
{
    'name': "Gestión Instituto",  # Titulo del módulo
    # Resumen de la funcionaliadad
    'summary': "Gestionar un instituto, módulos, ciclos...",
    'description': """
Gestor de institutos (Version Simple)
==============
    """,

    # Indicamos que es una aplicación
    'application': True,
    'author': "Walter Martín Lopes",
    'website': "http://apuntesfpinformatica.es",
    'category': 'Tools',
    'version': '0.1',
    'depends': ['base'],

    'data': [
        'security/ir.model.access.csv',
        # Cargamos las vistas
        'views/ciclo_formativo.xml',
        'views/modulo_formativo.xml',
        'views/alumno.xml',
        'views/profesor.xml'
    ],
}
