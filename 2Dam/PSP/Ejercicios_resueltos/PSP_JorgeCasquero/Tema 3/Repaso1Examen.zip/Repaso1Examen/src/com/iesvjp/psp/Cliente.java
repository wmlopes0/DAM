package com.iesvjp.psp;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class Cliente {

	private static int puerto = 8000;
	// private Socket cliente;

	public static void main(String[] args) {
		Socket cliente;
		DataInputStream flujoEntrada;
		try {
			cliente = new Socket("localhost", puerto);
			System.out.println("Conexion establecida con el servidor");

			while (true) {
				flujoEntrada = new DataInputStream(cliente.getInputStream());
				String mensaje = flujoEntrada.readUTF();
				System.out.println(mensaje);
				

			}

		} catch (IOException e) {
			e.printStackTrace();

			// cliente.close();

		}
	}
}
