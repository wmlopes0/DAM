# -*- coding: utf-8 -*-
from odoo import models, fields, api

#Definimos modelo CicloFormativo
class CicloFormativo(models.Model):
    _name = 'ciclo.formativo'  # Define el nombre técnico del modelo en Odoo
    _description = 'Ciclo Formativo'  # Descripción 

    # Campos del modelo
    # Nombre del ciclo formativo
    nombre = fields.Char(string="Nombre", required=True)  
    # Tipo de ciclo, con opciones predefinidas
    tipo = fields.Selection([
        ('grado_medio', 'Grado Medio'), 
        ('grado_superior', 'Grado Superior')
    ], string="Tipo", required=True)  
    # Duración del ciclo en años
    duracion = fields.Integer(string="Duración (años)", required=True)  

    # Relaciones
    # Campo que establece la relación uno-a-muchos con los módulos. 
    # 'modulo.formativo' se refiere al nombre técnico del modelo con el que se relaciona.
    # 'ciclo_formativo_id' es el campo en el modelo relacionado que hace referencia a este modelo.
    modulo_ids = fields.One2many('modulo.formativo', 'ciclo_formativo_id', string="Módulos")  
    
    #Get name para mostrar el nombre
    @api.depends('nombre')
    def name_get(self):
        result = []
        for record in self:
            name = record.nombre
            result.append((record.id, name))
        return result
