# -*- coding: utf-8 -*-
# Importamos modelos
from . import hospital_paciente
from . import hospital_medico
from . import hospital_diagnostico