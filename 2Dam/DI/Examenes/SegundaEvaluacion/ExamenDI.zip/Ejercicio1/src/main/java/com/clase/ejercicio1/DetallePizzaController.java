package com.clase.ejercicio1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author wmartinl01
 */
public class DetallePizzaController implements Initializable {
    
    @FXML
    private Label labelNombrePizza;
    @FXML
    private ImageView imagen;
    @FXML
    private Label labelIngredientes;
    @FXML
    private Label labelPrecio;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    void iniciarAtributos(Pizza pizzaSeleccionada) {
        //Seteo los campos
        imagen.setImage(new Image(getClass().getResourceAsStream("/com/clase/ejercicio1/IMG/" + pizzaSeleccionada.getFoto())));
        imagen.setPreserveRatio(true);
        labelNombrePizza.setText(pizzaSeleccionada.getNombre());
        labelIngredientes.setText(pizzaSeleccionada.getIngredientes());
        labelPrecio.setText(pizzaSeleccionada.getPrecio() + "€");
    }
    
}
