package com.clase.ejercicio1;

/**
 *
 * @author wmartinl01
 */
public class Pedido {

    //Atributos
    private int idPedido;
    private int idPizza;
    private String direccion;

    //Constructores
    public Pedido(int idPedido, int idPizza, String direccion) {
        this.idPedido = idPedido;
        this.idPizza = idPizza;
        this.direccion = direccion;
    }

    public Pedido(int idPizza, String direccion) {
        this.idPizza = idPizza;
        this.direccion = direccion;
    }

    //Getter y Setter
    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdPizza() {
        return idPizza;
    }

    public void setIdPizza(int idPizza) {
        this.idPizza = idPizza;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

}
