package psp;

import java.util.Iterator;

public class Piruja extends Thread {
	private String nombre;
	private Caldero caldero;

	public Piruja(Caldero caldero) {
		this.caldero = caldero;
		this.nombre = "Piruja";
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public void run() {
		// el enunciado nos dice que solo rellena 3 veces
		for (int i = 0; i < 3; i++) {
			caldero.Rellenar();
		}

	}

}
