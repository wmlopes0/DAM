# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import models, fields, api
from odoo.exceptions import ValidationError


#Definimos modelo HospitalPaciente
class HospitalPaciente(models.Model):
    _name = 'hospital.paciente'  # Define el nombre técnico del modelo
    _description = 'Paciente'    # Descripción 
    _rec_name = 'nombre'         # Especifica el campo a usar como representación de nombre del registro

    nombre = fields.Char(string='Nombre y Apellidos', required=True, index=True)  # Campo para el nombre, obligatorio e indexado para optimizar búsquedas
    sintomas = fields.Text(string='Síntomas')  # Campo de texto para los síntomas, permite texto largo

    # Restricción de SQL para garantizar nombres únicos
    _sql_constraints = [
        ('nombre_uniq', 'UNIQUE(nombre)', 'El nombre y apellidos del paciente deben ser únicos.'),  
    ]