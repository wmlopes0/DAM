package com.iesvjp.psp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class HiloServidor extends Thread {
	private Habitacion habitacion;
	private DataOutputStream flujoSalida;
	private DataInputStream flujoEntrada;
	private Socket cliente;

	public HiloServidor(Socket cliente, Habitacion habitacion) throws IOException {
		this.habitacion = habitacion;
		this.cliente = cliente;
		this.flujoSalida = new DataOutputStream(cliente.getOutputStream());
	}

	@Override
	public void run() {
		// genero la medida de los datos cada 10 segundos
		while (true) {
			habitacion.generarTemperatura();

			String mensaje = comprobaciones(habitacion);
			try {
				flujoSalida.writeUTF(mensaje);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private String comprobaciones(Habitacion habitacion) {

		String sms = "[Habitacion:" + habitacion.getNumHabitacion() + "]";
		int temp = habitacion.getTemp();
		if (temp >= 30) {
			return sms += "la temperatura es muy alta,(" + temp + ") se enciende el aire";

		}
		if (temp <= 15  ) {
			return sms += "la temperatura es muy baja,(" + temp + ") se enciende la calefaccion";

		}
		if (temp <= 30 && temp >=15 ) {
			return sms += "la temperatura es  Perfecta,(" + temp + ")";

		}

		return "";

	}
}
