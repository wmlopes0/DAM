import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int opc, num;
		PintaTabla tabla;

		
		do {
			System.out.println("0: Generar una tabla");
			System.out.println("1: salir");
			opc = teclado.nextInt();
			switch (opc) {
			case 0:
				num = GeneradorTablas.pedirNumero();
				GeneradorTablas.generarTabla(num);
				tabla = new PintaTabla(num);
				tabla.escribir();
			case 1:
				break;
			default:
				System.out.println("Opcion no valida");

			}

		} while (opc == 1);

	}

}
