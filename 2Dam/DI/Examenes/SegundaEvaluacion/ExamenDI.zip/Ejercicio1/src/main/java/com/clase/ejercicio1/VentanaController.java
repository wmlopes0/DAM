package com.clase.ejercicio1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author wmartinl01
 */
public class VentanaController implements Initializable {

    @FXML
    private TableView<Pizza> tablaPizzas;

    private ObservableList<Pizza> lPizzas;

    @FXML
    private TableColumn columnaIdPizza;
    @FXML
    private TableColumn columnaNombrePizza;
    @FXML
    private TableColumn columnaIngredientes;
    @FXML
    private TableColumn columnaPrecio;

    @FXML
    private TableView<Pedido> tablaPedidos;

    private ObservableList<Pedido> lPedidos;

    @FXML
    private TableColumn columnaIdPedido;
    @FXML
    private TableColumn columnaDireccion;
    @FXML
    private TableColumn columnaIdPizzaPedidos;
    @FXML
    private Button botonAniadirPedido;
    @FXML
    private Button botonEliminarPedido;
    @FXML
    private Button botonVerPizza;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Inicializo los Observables
        this.lPizzas = FXCollections.observableArrayList();
        this.lPedidos = FXCollections.observableArrayList();
        //Inicializo las columnas tabla pizzas
        this.columnaIdPizza.setCellValueFactory(new PropertyValueFactory<>("idPizza"));
        this.columnaNombrePizza.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        this.columnaIngredientes.setCellValueFactory(new PropertyValueFactory<>("ingredientes"));
        this.columnaPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        //Inicializo las columnas tabla pedidos
        this.columnaIdPedido.setCellValueFactory(new PropertyValueFactory<>("idPedido"));
        this.columnaIdPizzaPedidos.setCellValueFactory(new PropertyValueFactory<>("idPizza"));
        this.columnaDireccion.setCellValueFactory(new PropertyValueFactory<>("direccion"));
        //Actualizo tablas
        actualizarTablas();
    }

    public void actualizarTablas() {
        //Tabla pizzas
        lPizzas.clear();
        Utileria.recuperarPizzas(lPizzas);
        tablaPizzas.setItems(lPizzas);
        //Tabla pedidos
        lPedidos.clear();
        Utileria.recuperarPedidos(lPedidos);
        tablaPedidos.setItems(lPedidos);
    }

    @FXML
    private void aniadirPedido(ActionEvent event) {
        try {
            //Cargo la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/clase/ejercicio1/formularioAniadirPizza.fxml"));
            //Cargo la ventana
            Parent root = loader.load();
            //Controlador
            FormularioAniadirPizzaController controlador = loader.getController();
            controlador.iniciarAtributos(lPizzas);
            //Creo el scene
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(scene);
            stage.showAndWait();
            //Actualizo tabla
            actualizarTablas();
        } catch (IOException ex) {
//            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void eliminarPedido(ActionEvent event) {
        Pedido pedidoSeleccionado = tablaPedidos.getSelectionModel().getSelectedItem();
        if (pedidoSeleccionado != null) {
            //Elimino pedido de la bd
            Utileria.eliminarPedido(pedidoSeleccionado);
            //Actualizo tablas
            actualizarTablas();
            //Mensaje check
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setTitle("CHECK");
            alert.setContentText("¡Pedido eliminado correctamente!");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("¡Debes seleccionar un pedido!");
            alert.showAndWait();
        }
    }

    @FXML
    private void verPizza(ActionEvent event) {
        Pizza pizzaSeleccionada = tablaPizzas.getSelectionModel().getSelectedItem();
        if (pizzaSeleccionada != null) {
            try {
                //Cargo la vista
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/clase/ejercicio1/detallePizza.fxml"));
                //Cargo la ventana
                Parent root = loader.load();
                //Controlador
                DetallePizzaController controlador = loader.getController();
                controlador.iniciarAtributos(pizzaSeleccionada);
                //Creo el scene
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setScene(scene);
                stage.showAndWait();
            } catch (IOException ex) {
//            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("¡Debes seleccionar una pizza!");
            alert.showAndWait();
        }
    }

}
