package ejercicio2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 *
 * @author wmartinl01
 */
public class PanelExamen extends JPanel {

    //Variables globales
    private JLabel labelNombre;
    private JLabel labelOpacidad;
    private JTextField inputNombre;
    private JSlider opacidad;
    private JButton boton;
    private int valorSlider;

    //Constructor
    public PanelExamen() {
        super();
        valorSlider = 0;
        //Establezco el layout del JPanel
        setLayout(new GridLayout(5, 1));
        //Creo JLabelNombre
        crearLabelNombre();
        //Creo JTextFiel
        crearJTextField();
        //Creo JLabelOpacidad
        crearLabelOpacidad();
        //Creo JSlider
        crearJSlider();
        //Creo boton
        crearBoton();
    }

    private void crearLabelNombre() {
        labelNombre = new JLabel("Nombre");
        //Añado el label al JPanel
        add(labelNombre);
    }

    private void crearJTextField() {
        inputNombre = new JTextField("");
        //Añado el JTextField al JPanel
        add(inputNombre);
    }

    private void crearLabelOpacidad() {
        labelOpacidad = new JLabel("Opacidad");
        //Añado el label al JPanel
        add(labelOpacidad);
    }

    private void crearJSlider() {
        opacidad = new JSlider(0, 10);
        //Añado el ChangeListener
        opacidad.addChangeListener((ChangeEvent e) -> {
            valorSlider = opacidad.getValue();
        });
        //Añado el JSlider al JPanel
        add(opacidad);
    }

    private void crearBoton() {
        boton = new JButton("Enviar");
        //Inicio con el color de fondo azul
        boton.setBackground(Color.BLUE);
        //Recupero el nombre del JTextFieldNombre y Añado el ActionListener al boton
        boton.addActionListener((ActionEvent e) -> {
            String nombre = inputNombre.getText();
            JOptionPane.showMessageDialog(this, "La opacidad elegida por " + nombre + " es " + valorSlider, "Mensaje", JOptionPane.WARNING_MESSAGE);
        });
        //Añado el boton al JPanel
        add(boton);
    }
}
