from datetime import timedelta

from odoo import models, fields, api
from odoo.exceptions import ValidationError

# Definimos modelo Biblioteca socio, gestiona los socios de la biblioteca, incluyendo sus nombres, apellidos, identificador, y los ejemplares de cómics que tienen prestados.


class BibliotecaSocio(models.Model):
    # Nombre y descripcion del modelo
    _name = 'biblioteca.socio'
    _description = 'Socio de Biblioteca'

    # Atributos
    nombre = fields.Char('Nombre', required=True)
    apellidos = fields.Char('Apellidos', required=True)
    identificador = fields.Char('Identificador', required=True, unique=True)

    # Campo calculado para el nombre completo.Store=True para almacenarlo en la base de datos.
    nombre_completo = fields.Char(
        string='Nombre Completo', compute='_compute_nombre_completo', store=True)

    # Debemos relacionar socios con comics, lo haré con una relación One2Many hacia ejemplares de comics prestados
    ejemplares_prestados_ids = fields.One2many(
        'biblioteca.comic.ejemplar',  # Modelo relacionado
        'socio_id',  # Campo de "enlace" en el modelo relacionado
        string='Ejemplares Prestados'
    )

    # Utilizo @api.depends para asegurarse de que el campo calculado se actualice automáticamente cuando cambien los valores de nombre o apellidos.

    @api.depends('nombre', 'apellidos')
    def _compute_nombre_completo(self):
        for record in self:
            record.nombre_completo = f"{record.nombre} {record.apellidos}"

    # Representación del nombre de cada registro del modelo biblioteca.socio.
    _rec_name = 'nombre_completo'
