# -*- coding: utf-8 -*-
# Importamos modelos
from . import cicloFormativo
from . import moduloFormativo
from . import alumno
from . import profesor