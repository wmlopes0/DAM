package com.clase.ejercicio1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;

/**
 *
 * @author wmartinl01
 */
public class Utileria {

    public static Connection establecerConexion() {
        Connection conexion = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost/pizzeria?user=root&password=");
            System.out.println("CONEXIÓN ESTABLECIDA CORRECTAMENTE");
        } catch (ClassNotFoundException ex) {
//            ex.printStackTrace();
        } catch (SQLException ex) {
            System.out.println("ERROR DE CONEXIÓN");
        }
        return conexion;
    }

    public static void recuperarPizzas(ObservableList<Pizza> lPizzas) {
        Connection conexion = establecerConexion();
        PreparedStatement sentenciaPreparada = null;

        try {
            String sql = "SELECT * FROM pizzas";
            sentenciaPreparada = conexion.prepareCall(sql);
            ResultSet resultado = sentenciaPreparada.executeQuery();
            while (resultado.next()) {
                lPizzas.add(new Pizza(resultado.getInt("idPizza"), resultado.getString("nombre"), resultado.getString("foto"), resultado.getString("ingredientes"), resultado.getFloat("precio")));
            }
            //Libero recursos
            sentenciaPreparada.close();
            conexion.close();
        } catch (SQLException ex) {
//            Logger.getLogger(Utileria.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void recuperarPedidos(ObservableList<Pedido> lPedidos) {
        Connection conexion = establecerConexion();
        PreparedStatement sentenciaPreparada = null;

        try {
            String sql = "SELECT * FROM pedidos";
            sentenciaPreparada = conexion.prepareCall(sql);
            ResultSet resultado = sentenciaPreparada.executeQuery();
            while (resultado.next()) {
                lPedidos.add(new Pedido(resultado.getInt("idPedido"), resultado.getInt("idPizza"), resultado.getString("direccion")));
            }
            //Libero recursos
            sentenciaPreparada.close();
            conexion.close();
        } catch (SQLException ex) {
//            Logger.getLogger(Utileria.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static void aniadirPizza(Pizza pizza) {
        Connection conexion = establecerConexion();
        PreparedStatement sentenciaPreparada = null;
        try {
            String sql = "INSERT INTO pizzas (nombre,foto,ingredientes,precio) VALUES (?,?,?,?)";
            sentenciaPreparada = conexion.prepareCall(sql);
            sentenciaPreparada.setString(1, pizza.getNombre());
            sentenciaPreparada.setString(2, pizza.getFoto());
            sentenciaPreparada.setString(3, pizza.getIngredientes());
            sentenciaPreparada.setFloat(4, pizza.getPrecio());
            int registrosAfectados = sentenciaPreparada.executeUpdate();
            System.out.println("Actualizados " + registrosAfectados + " registros.");
            //Libero recursos
            sentenciaPreparada.close();
            conexion.close();
        } catch (SQLException ex) {
//            Logger.getLogger(Utileria.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static void aniadirPedido(Pedido pedido) {
        Connection conexion = establecerConexion();
        PreparedStatement sentenciaPreparada = null;
        try {
            String sql = "INSERT INTO pedidos (idPizza,direccion) VALUES (?,?)";
            sentenciaPreparada = conexion.prepareCall(sql);
            sentenciaPreparada.setInt(1, pedido.getIdPizza());
            sentenciaPreparada.setString(2, pedido.getDireccion());
            int registrosAfectados = sentenciaPreparada.executeUpdate();
            System.out.println("Actualizados " + registrosAfectados + " registros.");
            //Libero recursos
            sentenciaPreparada.close();
            conexion.close();
        } catch (SQLException ex) {
//            Logger.getLogger(Utileria.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static void eliminarPedido(Pedido pedidoSeleccionado) {
        Connection conexion = establecerConexion();
        PreparedStatement sentenciaPreparada = null;
        try {
            String sql = "DELETE FROM pedidos WHERE idPedido=?";
            sentenciaPreparada = conexion.prepareCall(sql);
            sentenciaPreparada.setInt(1, pedidoSeleccionado.getIdPedido());
            int registrosAfectados = sentenciaPreparada.executeUpdate();
            System.out.println("Actualizados " + registrosAfectados + " registros.");
            //Libero recursos
            sentenciaPreparada.close();
            conexion.close();
        } catch (SQLException ex) {
//            Logger.getLogger(Utileria.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
