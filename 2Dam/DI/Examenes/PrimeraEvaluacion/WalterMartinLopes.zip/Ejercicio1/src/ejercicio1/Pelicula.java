package ejercicio1;

/**
 *
 * @author wmartinl01
 */
public class Pelicula {

    //Atributos
    private int idPelicula;
    private String titulo;
    private String duracion;
    private String director;

    //Constructor
    public Pelicula(int idPelicula, String titulo, String duracion, String director) {
        this.idPelicula = idPelicula;
        this.titulo = titulo;
        this.duracion = duracion;
        this.director = director;
    }

    //Getter y Setter
    public int getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(int idPelicula) {
        this.idPelicula = idPelicula;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

}
