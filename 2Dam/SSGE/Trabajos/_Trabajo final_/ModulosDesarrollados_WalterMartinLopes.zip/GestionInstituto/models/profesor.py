from odoo import models, fields, api


class Profesor(models.Model):
    # Define el nombre técnico del modelo en Odoo.
    _name = 'profesor.formativo'
    _description = 'Profesor'  # Descripcion

    # Campos del modelo
    # Nombre del profesor.
    nombre = fields.Char(string="Nombre", required=True)
    # DNI del profesor, identificador único.
    dni = fields.Char(string="DNI", required=True)
    # Especialidad académica o profesional del profesor.
    especialidad = fields.Char(string="Especialidad", required=True)

    # Relaciones
    # Campo One2many que relaciona el profesor con los módulos que imparte.
    # 'modulo.formativo' es el modelo relacionado y 'profesor_id' es el campo en ese modelo que establece la conexión de vuelta.
    modulo_ids = fields.One2many(
        'modulo.formativo', 'profesor_id', string="Módulos Impartidos")

 # Get name para mostrar el nombre
    @api.depends('nombre')
    def name_get(self):
        result = []
        for record in self:
            name = record.nombre
            result.append((record.id, name))
        return result
