module com.clase.ejercicio1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires java.sql;

    opens com.clase.ejercicio1 to javafx.fxml;
    exports com.clase.ejercicio1;
}
