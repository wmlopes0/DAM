import java.util.InputMismatchException;
import java.util.Scanner;

public class GeneradorTablas {
	private int num;

	public GeneradorTablas() {
		super();
		this.num = 0;
	}

	public static int pedirNumero() {

		Scanner teclado = new Scanner(System.in);
		System.out.print("Introduce el numero del que quieres generar la tabla ");
		int num;
		boolean error;
		do {
			try {
				num = teclado.nextInt();
				error = false;
			} catch (InputMismatchException e) {
				System.out.println("Debe introducir un numero entero. ");
				error = true;
				num = 0;
				teclado.next();
			}
		} while (error);
		return num;
	}

	public static void generarTabla(int num) {
		int result;
		for (int i = 0; i < 10; i++) {
			
			result = num * i;
			
			System.out.println(num + "x" + i +" =" +result);
			

		}
	}
}
