from datetime import timedelta

from odoo import models, fields, api
from odoo.exceptions import ValidationError

# Definimos modelo Biblioteca comic ejemplar,maneja los ejemplares individuales de los cómics disponibles para préstamo. Cada ejemplar estará vinculado al cómic al que pertenece y, si está prestado, al socio que lo tiene.

class BibliotecaComicEjemplar(models.Model):
    # Nombre y descripcion del modelo
    _name = 'biblioteca.comic.ejemplar'
    _description = 'Ejemplar de Cómic para Préstamo'

    # Asociacion Many2One a comic
    comic_id = fields.Many2one('biblioteca.comic', string='Cómic',
                               required=True, help='Cómic al que pertenece este ejemplar')
    # Asociacion Many2One a socio
    socio_id = fields.Many2one(
        'biblioteca.socio', string='Prestado a', help='Socio al que se ha prestado el ejemplar')

    # Atributos
    # Help, se utiliza para proporcionar información adicional o descriptiva sobre el propósito o la función de un campo específico
    fecha_prestamo = fields.Date(string='Fecha de Préstamo', default=fields.Date.context_today,
                                 help='Fecha en la que se ha prestado el ejemplar')
    fecha_retorno_prevista = fields.Date(
        string='Fecha Prevista de Retorno', help='Fecha en la que se espera que retorne el ejemplar')

    # Indica que este método se llamará cuando cambien los campos 'fecha_prestamo' o 'fecha_retorno_prevista'
    @api.constrains('fecha_prestamo', 'fecha_retorno_prevista')
    def _check_fechas_prestamo(self):
        # Itera sobre cada registro (ejemplar de cómic) en el modelo actual
        for record in self:
            # Verifica si la fecha de préstamo está definida y es posterior a la fecha actual
            if record.fecha_prestamo and record.fecha_prestamo > fields.Date.today():
                # Si es así, lanza una excepción de validación indicando que la fecha de préstamo no puede ser en el futuro
                raise ValidationError(
                    'La fecha de préstamo no puede ser posterior a la fecha de hoy.')
            # Verifica si la fecha prevista de retorno está definida y es anterior a la fecha actual
            if record.fecha_retorno_prevista and record.fecha_retorno_prevista < fields.Date.today():
                # Si es así, lanza una excepción de validación indicando que la fecha de retorno no puede ser en el pasado
                raise ValidationError(
                    'La fecha prevista de retorno no puede ser anterior al día de hoy.')
