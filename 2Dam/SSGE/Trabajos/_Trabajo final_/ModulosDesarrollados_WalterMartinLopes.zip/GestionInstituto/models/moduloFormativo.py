from odoo import models, fields, api


class Modulo(models.Model):
    _name = 'modulo.formativo'  # Define el nombre técnico del modelo en Odoo
    _description = 'Modulo Formativo'  # Descripción

    # Campos del modelo
    nombre = fields.Char(string="Nombre", required=True)  # Nombre del módulo
    # Descripción detallada del módulo
    descripcion = fields.Text(string="Descripción")
    horas_lectivas = fields.Integer(
        string="Horas Lectivas", required=True)  # Número de horas lectivas

    # Relaciones
    # Establece la relación muchos-a-uno con CicloFormativo. 'ondelete="cascade"' indica que si se elimina el CicloFormativo, los módulos relacionados también se eliminarán.
    ciclo_formativo_id = fields.Many2one(
        'ciclo.formativo', string="Ciclo Formativo", ondelete='cascade')

    # Campo many2many que relaciona el módulo con los alumnos. Requiere una tabla de relación ('modulo_alumno_rel') y los nombres de las columnas en esa tabla ('modulo_id' y 'alumno_id').
    alumno_ids = fields.Many2many('alumno.formativo', 'modulo_alumno_rel',
                                  'modulo_id', 'alumno_id', string="Alumnos Matriculados")

    # Campo many2one que relaciona el módulo con un profesor. No es obligatorio que un módulo tenga un profesor asignado inicialmente.
    profesor_id = fields.Many2one(
        'profesor.formativo', string="Profesor", required=False)


    # Indica que el método debe ser llamado cuando cambie el valor del campo 'nombre'.
    # Ayuda a Odoo a saber que el nombre mostrado puede depender de este campo y necesita ser actualizado si 'nombre' cambia.
    @api.depends('nombre')
    def name_get(self):
        # Inicializa una lista vacía para almacenar los nombres personalizados de los registros.
        result = []

        # Itera sobre cada registro en el conjunto actual ('self' representa el conjunto de registros del modelo).
        for record in self:
            # Obtiene el valor del campo 'nombre' del registro actual para usarlo como parte del nombre mostrado.
            name = record.nombre

            # Añade una tupla al resultado, donde el primer elemento es el ID del registro
            # y el segundo es el nombre personalizado que definiste.
            result.append((record.id, name))

        # Devuelve la lista de tuplas que representa los nombres personalizados de los registros.
        # Cada tupla contiene el ID del registro y el nombre personalizado para mostrar.
        return result
