# -*- coding: utf-8 -*-
{
    'name': "Gestión Hospital",  # Titulo del módulo
    'summary': "Gestionar un hospital",  # Resumen de la funcionaliadad
    'description': """
Gestor de hospital (Version Simple)
==============
    """,  

    #Indicamos que es una aplicación
    'application': True,
    'author': "Walter Martín Lopes",
    'website': "http://apuntesfpinformatica.es",
    'category': 'Tools',
    'version': '0.1',
    'depends': ['base'],

    'data': [
        'security/ir.model.access.csv',
        #Cargamos las vistas
        'views/hospital_paciente.xml',
        'views/hospital_medico.xml',
        'views/hospital_diagnostico.xml',
        'views/hospital_diagnostico_calendar.xml'
    ],
}
