package com.iesvjp.psp;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
	private static final int PUERTO = 8000;

	public static void main(String[] args) {
		ServerSocket servidor = null;
		Habitacion habitacion;
		try {
			servidor = new ServerSocket(PUERTO);
			System.out.println("Esperando conexión en el puerto " + PUERTO);
			Socket cliente = null;
			while (true) {
				habitacion = new Habitacion();
				cliente = servidor.accept();
				System.out.println("Conexión establecida con " + cliente.getInetAddress().getHostName());

				// enviamos la primera medida de temperatura

				// generamos la medida de los datos cada 10 segundos
				HiloServidor hilo = new HiloServidor(cliente, habitacion);
				
				hilo.start();
				
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (servidor != null) {
					servidor.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
